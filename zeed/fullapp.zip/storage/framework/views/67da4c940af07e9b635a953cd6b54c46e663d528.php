;

<link href="<?php echo e(asset('css/items.css')); ?>" rel="stylesheet">

<?php $__env->startSection('content'); ?>

   <div class="middle">
      <div class="follow-unfollow">          
         <button type="submit" class="justbtn" ><a href=<?php echo e(route('create')); ?>> Create product</a> </button>     
      </div>
        <?php if(count($list) > 0 ): ?>
          
              <div class="userbox">
               <!---------------------each users -----------------> 
               <div class="userContainer">
                  <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <div class="each-user">
                           <div class="productname"> <?php echo e($item->product_name); ?> </div>
                           <div id="followers-count" class="followers-count <?php echo e($item->id); ?> " > 2 sales </div>
                           <div id="followers-count"> <?php echo e($item->category); ?> </div>
                           <a href="#"> <div class="profileview">view details</div></a>
                           <a href="#"> <div class="profileview"> <?php echo e($item->available); ?></div></a>   
                     
                      <div id="followers-count">created: <?php echo e($item->created_at); ?> </div> 

                      <div class="follow-unfollow">     
                        <form action="/delete/<?php echo e($item->id); ?>" method="POST">
                           <?php echo e(csrf_field()); ?>

                           <?php echo e(method_field('DELETE')); ?>

                           <button type="submit" class="deletebtn" > Delete </button> 
                         </form>                           
                        </div>

                        <div class="follow-unfollow">          
                              <button type="submit" class="justbtn" > update </button>     
                        </div>
                 </div>                                                
                
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <!---------------------each of each users ----------------->  
                </div>  
             </div>
           
        <?php else: ?>
            <h4>there are no products available</h4>
        <?php endif; ?>
   
   
   
   </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.appa", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Bukunmiiie\laravel\afri\resources\views/products/items.blade.php ENDPATH**/ ?>