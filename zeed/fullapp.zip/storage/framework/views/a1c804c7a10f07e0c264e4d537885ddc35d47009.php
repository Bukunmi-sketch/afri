;

<?php $__env->startSection('content'); ?>

<div class="middle">

    <div class="min-sub-container" style="display:block; position:relative;">
           <div class="spanheader">
               <span><h4> <?php echo e(__("Add a product")); ?> </h4></span>
           </div>

           <form action="/create" method="POST" enctype="multipart/form-data">
              <?php echo e(csrf_field()); ?>

              <?php echo $__env->make('common.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="inputbox-details">
                <input type="text" id="passa" name="product_name" style="<?php $__errorArgs = ['product_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border:1px solid red  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Product name" value=" <?php echo e(old("product_name")); ?> " autofocus >

                <?php $__errorArgs = ['product_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                 <span class="invalid-feedback" role="alert">
                     <strong><?php echo e($message); ?></strong>
                 </span>
                 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="inputbox-details">
                <textarea id="passa" name="product_description"  placeholder="Product description" autofocus value=" <?php echo e(old("product_description")); ?> "  style="<?php $__errorArgs = ['product_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border:1px solid red  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"></textarea>

                <?php $__errorArgs = ['product_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                 <span class="invalid-feedback" role="alert">
                     <strong><?php echo e($message); ?></strong>
                 </span>
                 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="inputbox-details">
                <input type="number" id="passa" name="product_price" placeholder="Product price" value=" <?php echo e(old("product_price")); ?> "  autofocus style="<?php $__errorArgs = ['product_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border:1px solid red  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                <?php $__errorArgs = ['product_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                 <span class="invalid-feedback" role="alert">
                     <strong><?php echo e($message); ?></strong>
                 </span>
                 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

         <!--     <div class="images">
                <div id="upload" >
                    <img src="" onClick="trigger()" id="profileDisplay" >
                    <input type="file" name="product_imagea" onchange="displayImage(this)"   id="capture"  style="display:none;">
                    <i class="fa fa-camera" id="camera"></i>
                </div>

            <div id="upload" >
                    <img src="" onClick="trigger()" id="profileDisplay" >
                    <input type="file" name="product_imageb" onchange="displayImage(this)"   id="capture"  style="display:none;">
                    <i class="fa fa-camera" id="camera"></i>
                </div>

            </div>
            -->

            <div class="inputbox-details">
                <select name="category">
                    <option value="" disabled selected>Product Category</option>
                    <option value="cereals">Cereals</option>
                    <option value="Tubers">Tubers</option>
                    <option value="fruits">fruits</option>
                    <option value="Cottons">Cottons</option>
                </select>
                <?php $__errorArgs = ['product_avalable'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                 <span class="invalid-feedback" role="alert">
                     <strong><?php echo e($message); ?></strong>
                 </span>
                 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="inputbox-details">
                <select name="product_available">
                    <option value="" disabled selected>Product's availability</option>
                    <option value="available">Availble</option>
                    <option value="unavailable">Unavailable</option>

                </select>
                <?php $__errorArgs = ['product_avalable'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                 <span class="invalid-feedback" role="alert">
                     <strong><?php echo e($message); ?></strong>
                 </span>
                 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="button-details">
               <button class="submit" name="login">Add</button>
            </div>

        </form>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.appa", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Bukunmiiie\laravel\afri\resources\views/products/create.blade.php ENDPATH**/ ?>