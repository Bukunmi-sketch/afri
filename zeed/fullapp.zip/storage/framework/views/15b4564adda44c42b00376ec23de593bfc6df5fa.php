<?php $__env->startSection('content'); ?>
<div class="middle">
    <div class="min-sub-container" style="display:block; position:relative;">
        <div class="spanheader">
            <span><h4> <?php echo e(__("Add a product")); ?> </h4></span>
        </div>

        <form action="/create" method="POST">
           <?php echo e(csrf_field()); ?>

        <div class="inputbox-details">
             <input type="text" id="passa" name="inputbox" placeholder="Exam Name" autofocus required>
         </div>

         <div class="button-details">
            <button class="submit" name="login">Add</button>
         </div>

     </form>

 </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.appa", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Bukunmiiie\laravel\afri\resources\views/products/dashboard.blade.php ENDPATH**/ ?>