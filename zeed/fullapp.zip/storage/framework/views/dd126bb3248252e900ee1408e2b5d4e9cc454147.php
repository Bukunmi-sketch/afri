;

<link href="<?php echo e(asset('css/items.css')); ?>" rel="stylesheet">

<?php $__env->startSection('content'); ?>

   <div class="middle">
      <div class="follow-unfollow">
         <button type="submit" class="justbtn" ><a href=<?php echo e(route('create')); ?>> Available Orders</a> </button>
      </div>
        <?php if(count($order) > 0 ): ?>

              <div class="userbox">
               <!---------------------each users ----------------->
               <div class="userContainer">
                  <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customerOrders): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <div class="each-user">
                           <div class="productname"> <?php echo e($customerOrders->customers_name); ?> </div>
                           <div id="followers-count" class="followers-count <?php echo e($customerOrders->order_id); ?> " >  <?php echo e($customerOrders->order_id); ?></div>
                           <div id="followers-count"> <?php echo e($customerOrders->email); ?> </div>
                           <a href="#"> <div class="profileview"><?php echo e($customerOrders->cart_items); ?></div></a>
                           <a href="#"> <div class="profileview" style="font-size:1.3em"> <?php echo e($customerOrders->payment_status); ?></div></a>

                      <div id="followers-count">created: <?php echo e($customerOrders->amount); ?> </div>

                      <div class="follow-unfollow">
                        <form action="/deleteOrders/<?php echo e($customerOrders->id); ?>" method="POST">
                           <?php echo e(csrf_field()); ?>

                           <?php echo e(method_field('DELETE')); ?>

                           <button type="submit" class="deletebtn" > Delete </button>
                         </form>
                        </div>

                        <div class="follow-unfollow">
                              <button type="submit" class="justbtn" > update </button>
                        </div>
                 </div>

                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <!---------------------each of each users ----------------->
                </div>
             </div>

        <?php else: ?>
            <h4>there are no products available</h4>
        <?php endif; ?>



   </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.appa", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Bukunmiiie\laravel\afri\resources\views/products/order.blade.php ENDPATH**/ ?>