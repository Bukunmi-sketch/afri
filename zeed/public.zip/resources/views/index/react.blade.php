@extends("layouts.appa");

@section('content')
    <div id="example"></div>
@endsection