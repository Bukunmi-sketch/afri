<nav>
    <div class="container">
         <div class="bar" onclick="opennav()"> <i class="fa fa-navicon"></i> </div>

         <h2 class="logo">Admin Dashboard </h2>

         <div class="create">
                <?php if(auth()->guard()->check()): ?>
                <form action="<?php echo e(route('logout')); ?>" method="POST">
                     <?php echo csrf_field(); ?>
                    <button class="logout">logout</button>
                </form>
              <?php else: ?>
                <a href="<?php echo e(route('login')); ?>" class="login">Log in</a>

                <?php if(Route::has('register')): ?>
                    <a href="<?php echo e(route('register')); ?>" class="register">Register</a>
                <?php endif; ?>
            <?php endif; ?>
         </div>
    </div>
</nav>
<?php /**PATH C:\Users\Bukunmiiie\laravel\afri\resources\views\layouts\nav.blade.php ENDPATH**/ ?>