require('./bootstrap');

require('./components/Example');